from random import randint


def computer_play(heap_size):
    remove = heap_size % 3
    if remove == 0:
        remove = randint(1, 2)
    print("Computer removes {}".format(remove))
    return remove
        

def human_play(heap_size):
    limit = min(heap_size, 2)
    remove = 0
    prompt = "Quantity to remove (1-{}): ".format(limit)
    while remove < 1 or remove > limit:
        remove = int(input(prompt))
    return remove
    

def initial_heap():
    size = 0
    while size < 1 or size > 100:
        size = int(input("Size of initial heap (1-100): "))
    return size 

    
def human_first():
    choice = ''
    while choice not in ('Y', 'N'):
        choice = input("Human moves first [Y/N]? ").upper()[:1]
    return (choice == 'Y')
    
    
def play_game():
    heap_size = initial_heap()
    human_turn = human_first()
    while heap_size > 0:
        quantifier = "objects" if heap_size > 1 else "object"
        print("{} {} in heap.".format(heap_size, quantifier))
        if human_turn:
            heap_size -= human_play(heap_size)
        else:
            heap_size -= computer_play(heap_size)
        human_turn = not human_turn
    if human_turn:
        print("Computer wins!")
    else:
        print("You win!")


def play_again():
    choice = ''
    while choice not in ('Y', 'N'):
        choice = input("Play again [Y/N]? ").upper()[:1]
    return (choice == 'Y')

        
replay = True
while replay:
    play_game()
    replay = play_again()
