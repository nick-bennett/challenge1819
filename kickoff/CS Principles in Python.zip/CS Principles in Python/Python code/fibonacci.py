fibonacci = [0, 1]
for i in range(98):
    fibonacci.append(fibonacci[i] + fibonacci[i + 1])
print(fibonacci)
