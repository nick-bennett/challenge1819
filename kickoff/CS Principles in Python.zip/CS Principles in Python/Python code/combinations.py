def combinations(pool_size, sample_size):
    count = 1
    remaining = pool_size
    while remaining > pool_size - sample_size:
        count *= remaining
        remaining -= 1
        count /= (pool_size - remaining)
    return count


print(combinations(52, 5))
print(combinations(10, 10))
print(combinations(69, 5))
print(combinations(80, 20))
